<?php

$host = 'localhost';
$user = 'namdzpro';
$pass = 'iuemmaimai';
$db_name = 'blog';

$conn = new MySQLi($host, $user, $pass, $db_name);


if($conn->connect_error) {
    die('Database connect error:' . $conn->connect_error);
} 

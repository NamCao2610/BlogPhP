<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/admin/posts/index.php'; ?>">Quản lí bài đăng</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/users/index.php'; ?>">Quản lí người dùng</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/topics/index.php'; ?>">Quản lí chủ đề</a></li>
    </ul>
</div>